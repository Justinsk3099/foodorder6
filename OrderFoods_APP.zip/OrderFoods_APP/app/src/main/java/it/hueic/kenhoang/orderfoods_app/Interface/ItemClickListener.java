package it.hueic.kenhoang.orderfoods_app.Interface;

import android.view.View;

/**
 * Created by kenhoang on 26/01/2018.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
