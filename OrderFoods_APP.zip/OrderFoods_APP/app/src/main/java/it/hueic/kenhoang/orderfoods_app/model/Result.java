package it.hueic.kenhoang.orderfoods_app.model;

/**
 * Created by kenhoang on 09/02/2018.
 */

public class Result {
    public String message_id;
}
